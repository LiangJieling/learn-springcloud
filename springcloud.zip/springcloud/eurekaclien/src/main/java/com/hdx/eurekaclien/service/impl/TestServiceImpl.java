package com.hdx.eurekaclien.service.impl;

import com.hdx.eurekaclien.service.TestService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service("testServiceImpl")
public class TestServiceImpl implements TestService {
    @Value("${server.port}")
    private int port;

    @Override
    public String indexString() {
        return "辰星是小懒猪！！端口："+port;
    }
}
