package com.hdx.eurekaclien;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.SpringCloudApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

//@SpringCloudApplication
@SpringBootApplication
//@EnableEurekaServer    //@EnableEurekaClient注解（或@EnableDiscoveryClient）标注该应用程序是一个服务提供者
@EnableDiscoveryClient
public class EurekaclienApplication {

    public static void main(String[] args) {
        SpringApplication.run(EurekaclienApplication.class, args);
        System.out.println("服务提供者启动成功！");
    }

}
