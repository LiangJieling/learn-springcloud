package com.hdx.eurekaclien.controller;

import com.hdx.eurekaclien.service.TestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {

    @Autowired
    @Qualifier("testServiceImpl")
    private TestService testService;

    @GetMapping("index")
    public String testString(){
        return testService.indexString();
    }
}
