package com.hdx.eurekaclien.service;

public interface TestService {
    String indexString();
}
