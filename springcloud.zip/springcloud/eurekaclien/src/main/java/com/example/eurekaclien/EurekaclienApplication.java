package com.example.eurekaclien;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.SpringCloudApplication;

//@SpringBootApplication
@SpringCloudApplication
public class EurekaclienApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurekaclienApplication.class, args);
		System.out.println("服务提供者（即客户端）启动成功！！");
	}

}
