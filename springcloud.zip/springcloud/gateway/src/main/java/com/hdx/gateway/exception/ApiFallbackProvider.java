package com.hdx.gateway.exception;

import org.springframework.stereotype.Component;

/**
 * 错误拦截  ，暂时未写（预留）
 */
@Component
public class ApiFallbackProvider {
}
