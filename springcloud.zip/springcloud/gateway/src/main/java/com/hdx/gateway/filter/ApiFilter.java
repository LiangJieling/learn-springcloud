package com.hdx.gateway.filter;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

/**
 * 服务拦截
 *  例如：http://localhost:8088/api/index?token=12345 拦截后面的token
 */
@Component
public class ApiFilter extends ZuulFilter {
    @Override
    public String filterType() {
        //filterType 为过滤类型，可选值有 pre（路由之前）、rouঞng（路由之时）、post（路由之后）、error（发生错误时调用)
        return "pre";
    }

    @Override
    public int filterOrder() {
        //filterOrdery 为过滤的顺序，如果有多个过滤器，则数字越小越先执行
        return 0;
    }

    @Override
    public boolean shouldFilter() {
        //shouldFilter 表示是否过滤，这里可以做逻辑判断，true为过滤，false不过滤
        return false;
    }

    @Override
    public Object run() throws ZuulException {
        //run 为过滤器执行的具体逻辑，在这里可以做很多事情，比如：权限判断、合法性校验等。

        RequestContext context = RequestContext.getCurrentContext();
        HttpServletRequest request = context.getRequest();
        String token = request.getParameter("token");
        if(!"12345".equals(token)){
            context.setSendZuulResponse(false);
            context.setResponseStatusCode(401);
            try {
                context.getResponse().getWriter().write("token is error！");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }
}
